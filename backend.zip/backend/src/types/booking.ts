// src/types/booking.ts
export interface CustomerDetails {
    name: string;
    email: string;
    phone: string;
    address: string;
  }
  
  export interface ServiceItemCreateInput {
    name: string;
    description?: string | null;
    frequency?: string | null;
  }
  
  export interface CreateBookingRequest {
    area: number;
    dateTime: string;
    customerDetails: CustomerDetails;
    price: number;
    cleaningType: string;
    isBusinessCustomer: boolean;
    serviceItems: ServiceItemCreateInput[];
    duration: number;
  }
  
  export interface CalendarEventData {
    startTime: Date;
    endTime: Date;
    area: number;
    cleaningType: string;
    price: number;
    duration: number;
    serviceItems: {
      name: string;
      description: string;
      frequency: string;
    }[];
    isBusinessCustomer: boolean;
  }
  
  export interface BookingResponse {
    message: string;
    booking: any; // Replace with proper Booking type from Prisma
    calendarEvent: {
      id: string;
      htmlLink: string;
    };
  }