import { Router } from 'express';
import { BookingService } from '../services/bookingService';
import { EmailService } from '../services/emailService';
import { CalendarService } from '../services/calendarService';
import { validateBookingRequest } from '../middleware/validateBooking';
import { CreateBookingRequest } from '../types/booking';

const router = Router();
const bookingService = new BookingService();
const emailService = new EmailService();
const calendarService = new CalendarService();

// Create booking
router.post('/', validateBookingRequest, async (req, res) => {
  try {
    const bookingData: CreateBookingRequest = req.body;
    
    // Create booking and related entries
    const result = await bookingService.createBooking(bookingData);
    
    // Create calendar event
    const calendarEvent = await calendarService.createEvent(
      result.booking,
      result.customer
    );

    // Send confirmation email
    await emailService.sendBookingConfirmation({
      booking: result.booking,
      customer: result.customer,
      calendarEvent: calendarEvent.data
    });

    res.status(201).json({
      message: 'Booking created successfully!',
      booking: result.booking,
      calendarEvent: {
        id: calendarEvent.data.id,
        htmlLink: calendarEvent.data.htmlLink
      }
    });
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({
      error: 'Failed to create booking.',
      details: (error as Error).message,
    });
  }
});

// Get all bookings
router.get('/', async (req, res) => {
  try {
    const bookings = await bookingService.getAllBookings();
    res.json(bookings);
  } catch (error) {
    console.error('Error fetching bookings:', error);
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
});

// Get booking statistics
router.get('/stats', async (req, res) => {
  try {
    const stats = await bookingService.getBookingStats();
    res.json(stats);
  } catch (error) {
    console.error('Error fetching booking stats:', error);
    res.status(500).json({ error: 'Failed to fetch booking statistics' });
  }
});

// Get booking availability
router.get('/availability/:date', async (req, res) => {
  try {
    const date = new Date(req.params.date);
    if (isNaN(date.getTime())) {
      return res.status(400).json({ error: 'Invalid date format' });
    }

    const availability = await calendarService.getAvailableSlots(date);
    res.json(availability);
  } catch (error) {
    console.error('Error fetching availability:', error);
    res.status(500).json({ 
      error: 'Failed to fetch availability',
      details: (error as Error).message 
    });
  }
});

export default router;