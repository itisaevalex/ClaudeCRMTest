import { Router } from 'express';
import bookingRoutes from './bookingRoutes';
import customerRoutes from './customerRoutes';
import financeRoutes from './financeRoutes';
import calendarRoutes from './calendarRoutes';

const router = Router();

// Health check endpoint stays in main router
router.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'OK' });
});

// Mount sub-routers
router.use('/api/bookings', bookingRoutes);
router.use('/api/customers', customerRoutes);
router.use('/api/finances', financeRoutes);
router.use('/api/calendar', calendarRoutes);

export default router;